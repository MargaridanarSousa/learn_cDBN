package com.github.tDBN.dbn;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.io.FileNotFoundException;
import java.lang.Math;


import com.github.tDBN.utils.Edge;
import com.github.tDBN.utils.Utils;

public class DynamicBayesNet {

	private List<Attribute> attributes;

	private int markovLag;

	private BayesNet initialNet;

	public List<BayesNet> transitionNets;

	public DynamicBayesNet(List<Attribute> attributes, BayesNet initialNet, List<BayesNet> transitionNets) {
		this.attributes = attributes;
		this.initialNet = initialNet;
		this.transitionNets = transitionNets;
		this.markovLag = transitionNets.get(0).getMarkovLag();
	}

	public List<Attribute> getAttributes(){
		return attributes;
	}
	
	
	public List<BayesNet> getTrans(){
		return transitionNets;
	}
	
	
	public BayesNet getInit() {
		
		return initialNet;
	}
	
	
	
	
	public DynamicBayesNet(List<Attribute> attributes, List<BayesNet> transitionNets) {
		this(attributes, null, transitionNets);
	}

	public DynamicBayesNet generateParameters() {
		initialNet.generateParameters();
		for (BayesNet transitionNet : transitionNets)
			transitionNet.generateParameters();
		return this;
	}

	public void learnParameters(Observations o) {
		learnParameters(o, false);
	}

	public String learnParameters(Observations o, boolean stationaryProcess) {

		if (stationaryProcess) {
			// assert there is only one transition network
			if (transitionNets.size() > 1)
				throw new IllegalArgumentException("DBN has more than one transition network, cannot "
						+ "learn parameters considering a stationary process");

			return transitionNets.get(0).learnParameters(o, -1);

		} else {
			int T = transitionNets.size();
			for (int t = 0; t < T; t++) {
				transitionNets.get(t).learnParameters(o, t);
			}
		}
		return null;
	}

	public Observations generateObservations(int numIndividuals) {
		return generateObservations(numIndividuals, transitionNets.size(), false);
	}

	public Observations generateObservations(int numIndividuals, int numTransitions, boolean stationaryProcess) {
		int[][][] obsMatrix = generateObservationsMatrix(null, numIndividuals, numTransitions, stationaryProcess, false);
		return new Observations(attributes, obsMatrix);
	}

	public Observations forecast(Observations originalObservations, int numTransitions, boolean stationaryProcess,
			boolean mostProbable) {
		if (stationaryProcess) {
			// assert there is only one transition network
			if (transitionNets.size() > 1)
				throw new IllegalArgumentException("DBN has more than one transition network, cannot "
						+ "learn parameters considering a stationary process");

		}
		List<int[]> initialObservations = originalObservations.getFirst();
		int[][][] obsMatrix = generateObservationsMatrix(initialObservations, initialObservations.size(),
				numTransitions, stationaryProcess, mostProbable);
		return new Observations(originalObservations, obsMatrix);
	}

	public Observations forecast(Observations originalObservations) {
		return forecast(originalObservations, transitionNets.size(), false, false);
	}
	
	private int[][][] generateObservationsMatrix(List<int[]> initialObservations, int numIndividuals,
			int numTransitions, boolean stationaryProcess, boolean mostProbable) {
		// System.out.println("generating observations");

		if (!stationaryProcess && numTransitions > transitionNets.size())
			throw new IllegalArgumentException("DBN only has " + transitionNets.size() + " "
					+ "transitions defined, cannot generate " + numTransitions + ".");

		int n = attributes.size();
		//
		int[][][] obsMatrix = new int[numTransitions][numIndividuals][(markovLag + 1) * n];

		for (int subject = 0; subject < numIndividuals; subject++) {
			
			int[] observation0 = initialObservations != null ? initialObservations.get(subject) : initialNet
					.nextObservation(null, mostProbable);
			int[] observationT = observation0;
			for (int transition = 0; transition < numTransitions; transition++) {
				System.arraycopy(observationT, 0, obsMatrix[transition][subject], 0, n * markovLag);

				int[] observationTplus1 = stationaryProcess ? transitionNets.get(0).nextObservation(observationT,
						mostProbable) : transitionNets.get(transition).nextObservation(observationT, mostProbable);
				System.arraycopy(observationTplus1, 0, obsMatrix[transition][subject], n * markovLag, n);

				observationT = Arrays.copyOfRange(obsMatrix[transition][subject], n, (markovLag + 1) * n);
			}
		}

		return obsMatrix;
	}

	

	public static double[] compare(DynamicBayesNet original, DynamicBayesNet recovered) {
		return compare(original, recovered, false);
	}
	
	
	//List<int[]> 
		
	public static double[] compare(DynamicBayesNet original, DynamicBayesNet recovered, boolean verbose) {
		assert (original.transitionNets.size() == recovered.transitionNets.size());
		//int numTransitions = original.transitionNets.size();
		//List<int[]> counts = new ArrayList<int[]>(numTransitions);
		/*for (int t = 0; t < numTransitions; t++) {
			counts.add(BayesNet.compare(original.transitionNets.get(t), recovered.transitionNets.get(t), verbose));
		}*/
		return BayesNet.compare(original.transitionNets.get(0), recovered.transitionNets.get(0), verbose);
	}

	public String toDot(boolean compactFormat) {
		StringBuilder sb = new StringBuilder();
		String ls = System.getProperty("line.separator");
		String dl = ls + ls;
		int n = attributes.size();
		int T = transitionNets.size();

		if (compactFormat && (T != 1 || markovLag != 1))
			throw new IllegalStateException(
					"More than one transition network or Markov lag larger than 1, cannot create compact graph.");

		// digraph init
		sb.append("digraph dbn{" + dl);

		if (compactFormat) {
			for (int i = 0; i < n; i++) {
				sb.append("X" + i);
				String attributeName = attributes.get(i).getName();
				if (attributeName != null)
					sb.append("[label=\"" + attributeName);
				else
					sb.append("[label=\"X" + i);
				sb.append("\"];" + ls);
			}
			sb.append(ls);
		} else {
			for (int t = 0; t < T + markovLag; t++) {
				// slice t attributes
				for (int i = 0; i < n; i++) {
					sb.append("X" + i + "_" + t);
					String attributeName = attributes.get(i).getName();
					if (attributeName != null)
						sb.append("[label=\"" + attributeName);
					else
						sb.append("[label=\"X" + i);
					sb.append("[" + t + "]\"];" + ls);
				}
				sb.append(ls);
			}
		}
		sb.append(ls);

		// transition and intra-slice (t>0) edges
		for (int t = 0; t < T; t++)
			sb.append(transitionNets.get(t).toDot(t, compactFormat));

		sb.append(ls + "}" + ls);

		return sb.toString();
	}

	public String toString(boolean printParameters) {
		StringBuilder sb = new StringBuilder();
		String ls = System.getProperty("line.separator");

		if (initialNet != null)
			sb.append(initialNet.toString(-1, false));

		int i = 0;
		for (Iterator<BayesNet> iter = transitionNets.iterator(); iter.hasNext();) {
			sb.append(iter.next().toString(i, printParameters));
			i++;
			if (iter.hasNext())
				sb.append("-----------------" + ls + ls);
		}

		return sb.toString();
	}

	public String toString() {
		return toString(false);
	}
	
	
	
	public static double Mean( double[] obs) {
		
		double sum=0;
		
		for(int i=0; i <obs.length ; i++) {
			sum+=obs[i];
			
		}

		
		sum= sum/(double)obs.length;
		return sum;
	}
	
	
	public static double StandDes( double[] obs,double mean) {
		
		double sum=0;
		
		for(int i=0; i <obs.length ; i++) {
			sum+= Math.pow(obs[i]-mean,2);
			
		}
		sum=sum/(double) obs.length;
		sum= (Math.sqrt(sum)/ Math.sqrt((double) obs.length))*1.96;
		return sum;
	}
	
	
	
}