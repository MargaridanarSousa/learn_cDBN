package com.github.tDBN.dbn;

//import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.lang.Math;

import com.github.tDBN.utils.Edge;

public class DynamicBayesNet {

	private List<Attribute> attributes;

	private int markovLag;

	private BayesNet initialNet;

	private List<BayesNet> transitionNets;

	public DynamicBayesNet(List<Attribute> attributes, BayesNet initialNet, List<BayesNet> transitionNets) {
		this.attributes = attributes;
		this.initialNet = initialNet;
		this.transitionNets = transitionNets;
		this.markovLag = transitionNets.get(0).getMarkovLag();
	}

	public DynamicBayesNet(List<Attribute> attributes, List<BayesNet> transitionNets) {
		this(attributes, null, transitionNets);
	}

	public DynamicBayesNet generateParameters() {
		initialNet.generateParameters();
		for (BayesNet transitionNet : transitionNets)
			transitionNet.generateParameters();
		return this;
	}

	public void learnParameters(Observations o) {
		learnParameters(o, false);
	}

	public String learnParameters(Observations o, boolean stationaryProcess) {

		if (stationaryProcess) {
			// assert there is only one transition network
			if (transitionNets.size() > 1)
				throw new IllegalArgumentException("DBN has more than one transition network, cannot "
						+ "learn parameters considering a stationary process");

			return transitionNets.get(0).learnParameters(o, -1);

		} else {
			int T = transitionNets.size();
			for (int t = 0; t < T; t++) {
				transitionNets.get(t).learnParameters(o, t);
			}
		}
		return null;
	}

	public Observations generateObservations(int numIndividuals) {
		return generateObservations(numIndividuals, transitionNets.size(), false);
	}

	public Observations generateObservations(int numIndividuals, int numTransitions, boolean stationaryProcess) {
		int[][][] obsMatrix = generateObservationsMatrix(null, numIndividuals, numTransitions, stationaryProcess, false);
		return new Observations(attributes, obsMatrix);
	}

	public Observations forecast(Observations originalObservations, int numTransitions, boolean stationaryProcess,
			boolean mostProbable) {
		if (stationaryProcess) {
			// assert there is only one transition network
			if (transitionNets.size() > 1)
				throw new IllegalArgumentException("DBN has more than one transition network, cannot "
						+ "learn parameters considering a stationary process");

		}
		List<int[]> initialObservations = originalObservations.getFirst();
		int[][][] obsMatrix = generateObservationsMatrix(initialObservations, initialObservations.size(),
				numTransitions, stationaryProcess, mostProbable);
		return new Observations(originalObservations, obsMatrix);
	}

	public Observations forecast(Observations originalObservations) {
		return forecast(originalObservations, transitionNets.size(), false, false);
	}
	
	private int[][][] generateObservationsMatrix(List<int[]> initialObservations, int numIndividuals,
			int numTransitions, boolean stationaryProcess, boolean mostProbable) {
		// System.out.println("generating observations");

		if (!stationaryProcess && numTransitions > transitionNets.size())
			throw new IllegalArgumentException("DBN only has " + transitionNets.size() + " "
					+ "transitions defined, cannot generate " + numTransitions + ".");

		int n = attributes.size();
		//
		int[][][] obsMatrix = new int[numTransitions][numIndividuals][(markovLag + 1) * n];

		for (int subject = 0; subject < numIndividuals; subject++) {
			int[] observation0 = initialObservations != null ? initialObservations.get(subject) : initialNet
					.nextObservation(null, mostProbable);
			int[] observationT = observation0;
			for (int transition = 0; transition < numTransitions; transition++) {
				System.arraycopy(observationT, 0, obsMatrix[transition][subject], 0, n * markovLag);

				int[] observationTplus1 = stationaryProcess ? transitionNets.get(0).nextObservation(observationT,
						mostProbable) : transitionNets.get(transition).nextObservation(observationT, mostProbable);
				System.arraycopy(observationTplus1, 0, obsMatrix[transition][subject], n * markovLag, n);

				observationT = Arrays.copyOfRange(obsMatrix[transition][subject], n, (markovLag + 1) * n);
			}
		}

		return obsMatrix;
	}

	

	public static double[] compare(DynamicBayesNet original, DynamicBayesNet recovered) {
		return compare(original, recovered, false);
	}
	
	
	//List<int[]> 
		
	public static double[] compare(DynamicBayesNet original, DynamicBayesNet recovered, boolean verbose) {
		assert (original.transitionNets.size() == recovered.transitionNets.size());
		//int numTransitions = original.transitionNets.size();
		//List<int[]> counts = new ArrayList<int[]>(numTransitions);
		/*for (int t = 0; t < numTransitions; t++) {
			counts.add(BayesNet.compare(original.transitionNets.get(t), recovered.transitionNets.get(t), verbose));
		}*/
		return BayesNet.compare(original.transitionNets.get(0), recovered.transitionNets.get(0), verbose);
	}

	public String toDot(boolean compactFormat) {
		StringBuilder sb = new StringBuilder();
		String ls = System.getProperty("line.separator");
		String dl = ls + ls;
		int n = attributes.size();
		int T = transitionNets.size();

		if (compactFormat && (T != 1 || markovLag != 1))
			throw new IllegalStateException(
					"More than one transition network or Markov lag larger than 1, cannot create compact graph.");

		// digraph init
		sb.append("digraph dbn{" + dl);

		if (compactFormat) {
			for (int i = 0; i < n; i++) {
				sb.append("X" + i);
				String attributeName = attributes.get(i).getName();
				if (attributeName != null)
					sb.append("[label=\"" + attributeName);
				else
					sb.append("[label=\"X" + i);
				sb.append("\"];" + ls);
			}
			sb.append(ls);
		} else {
			for (int t = 0; t < T + markovLag; t++) {
				// slice t attributes
				for (int i = 0; i < n; i++) {
					sb.append("X" + i + "_" + t);
					String attributeName = attributes.get(i).getName();
					if (attributeName != null)
						sb.append("[label=\"" + attributeName);
					else
						sb.append("[label=\"X" + i);
					sb.append("[" + t + "]\"];" + ls);
				}
				sb.append(ls);
			}
		}
		sb.append(ls);

		// transition and intra-slice (t>0) edges
		for (int t = 0; t < T; t++)
			sb.append(transitionNets.get(t).toDot(t, compactFormat));

		sb.append(ls + "}" + ls);

		return sb.toString();
	}

	public String toString(boolean printParameters) {
		StringBuilder sb = new StringBuilder();
		String ls = System.getProperty("line.separator");

		if (initialNet != null)
			sb.append(initialNet.toString(-1, false));

		int i = 0;
		for (Iterator<BayesNet> iter = transitionNets.iterator(); iter.hasNext();) {
			sb.append(iter.next().toString(i, printParameters));
			i++;
			if (iter.hasNext())
				sb.append("-----------------" + ls + ls);
		}

		return sb.toString();
	}

	public String toString() {
		return toString(false);
	}
	
	
	
	public static double Mean( double[] obs) {
		
		double sum=0;
		
		for(int i=0; i <obs.length ; i++) {
			sum+=obs[i];
			
		}
		
		//System.out.println("sum"+sum);
		
		//System.out.println("length"+obs.length);
		
		sum= sum/(double)obs.length;
		return sum;
	}
	
	
	public static double StandDes( double[] obs,double mean) {
		
		double sum=0;
		
		for(int i=0; i <obs.length ; i++) {
			sum+= Math.pow(obs[i]-mean,2);
			
		}
		sum=sum/(double) obs.length;
		sum= (Math.sqrt(sum)/ Math.sqrt((double) obs.length))*1.96;
		return sum;
	}
	
	
	

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		

		
		Attribute a1 = new NominalAttribute();
		a1.setName("me");
		a1.add("yes");
		a1.add("no");
		a1.add("ok");

		Attribute a2 = new NumericAttribute();
		a2.add("10");
		a2.add("20");
		a2.add("30");
		//a2.add("40");

		Attribute a3 = new NumericAttribute();
		a3.add("0");
		a3.add("1");
		a3.add("2");
		//a3.add("3");

		Attribute a4 = new NumericAttribute();
		a4.add("0");
		a4.add("1");
		a4.add("2");
		//a4.add("3");
		
		
		Attribute a5 = new NumericAttribute();
		a5.add("0");
		a5.add("1");
		a5.add("2");
		//a5.add("3");
		
		Attribute a6 = new NumericAttribute();
		a6.add("0");
		a6.add("1");
		a6.add("2");
		//a6.add("3");
		
		Attribute a7 = new NumericAttribute();
		a7.add("0");
		a7.add("1");
		a7.add("2");
		//a7.add("3");
		
		Attribute a8 = new NumericAttribute();
		a8.add("0");
		a8.add("1");
		a8.add("2");
		
		Attribute a9 = new NumericAttribute();
		a9.add("0");
		a9.add("1");
		a9.add("2");
		//a9.add("3");
		
		Attribute a10 = new NumericAttribute();
		a10.add("0");
		a10.add("1");
		a10.add("2");
		
		
		
		//a10.add("2");
		//a10.add("3");
		
	/*	Attribute a11 = new NumericAttribute();
		a11.add("0");
		a11.add("1");
		
		Attribute a12 = new NumericAttribute();
		a12.add("0");
		a12.add("1");
		
		Attribute a13 = new NumericAttribute();
		a13.add("0");
		a13.add("1");
		
		Attribute a14 = new NumericAttribute();
		a14.add("0");
		a14.add("1");
		
		Attribute a15 = new NumericAttribute();
		a15.add("0");
		a15.add("1");
		
		Attribute a16 = new NumericAttribute();
		a16.add("0");
		a16.add("1");
		
		Attribute a17 = new NumericAttribute();
		a17.add("0");
		a17.add("1");
		
		Attribute a18 = new NumericAttribute();
		a18.add("0");
		a18.add("1");
		
		Attribute a19 = new NumericAttribute();
		a19.add("0");
		a19.add("1");
		
		Attribute a20 = new NumericAttribute();
		a20.add("0");
		a20.add("1");*/

		//a6,a7,a8,a9,a10
		//,a6,a7,a8,a9,a10
		//,a11,a12,a13,a14,a15,a16,a17,a18,a19,a20
		
		//a6,a7,a8,a9,a10
		
		List<Attribute> a = Arrays.asList(a1,a2,a3,a4);
		
		Edge e00 = new Edge(0,0);
		Edge e01 = new Edge(0,1);
		Edge e02 = new Edge(0,2);
		Edge e03 = new Edge(0,3);
		Edge e04 = new Edge(0,4);
		Edge e05 = new Edge(0,5);
		Edge e06 = new Edge(0,6);
		Edge e07 = new Edge(0,7);
		Edge e08 = new Edge(0,8);
		Edge e09 = new Edge(0,9);
		
		
		Edge e10 = new Edge(1,0);
		Edge e11 = new Edge(1,1);
		Edge e12 = new Edge(1,2);
		Edge e13 = new Edge(1,3);
		Edge e14 = new Edge(1,4);
		Edge e15 = new Edge(1,5);
		Edge e16 = new Edge(1,6);
		Edge e17 = new Edge(1,7);
		Edge e18 = new Edge(1,8);
		Edge e19 = new Edge(1,9);
		
		Edge e20 = new Edge(2,0);
		Edge e21 = new Edge(2,1);
		Edge e22 = new Edge(2,2);
		Edge e23 = new Edge(2,3);
		Edge e24 = new Edge(2,4);
		Edge e25 = new Edge(2,5);
		Edge e26 = new Edge(2,6);
		Edge e27 = new Edge(2,7);
		Edge e28 = new Edge(2,8);
		Edge e29 = new Edge(2,9);
		
		
		Edge e30 = new Edge(3,0);
		Edge e31 = new Edge(3,1);
		Edge e32 = new Edge(3,2);
		Edge e33 = new Edge(3,3);
		Edge e34 = new Edge(3,4);
		Edge e35 = new Edge(3,5);
		Edge e36 = new Edge(3,6);
		Edge e37 = new Edge(3,7);
		Edge e38 = new Edge(3,8);
		Edge e39 = new Edge(3,9);
		
		
		Edge e40 = new Edge(4,0);
		Edge e41 = new Edge(4,1);
		Edge e42 = new Edge(4,2);
		Edge e43 = new Edge(4,3);
		Edge e44 = new Edge(4,4);
		Edge e45 = new Edge(4,5);
		Edge e46 = new Edge(4,6);
		Edge e47 = new Edge(4,7);
		Edge e48 = new Edge(4,8);
		Edge e49 = new Edge(4,9);
		
		Edge e50 = new Edge(5,0);
		Edge e51 = new Edge(5,1);
		Edge e52 = new Edge(5,2);
		Edge e53 = new Edge(5,3);
		Edge e54 = new Edge(5,4);
		Edge e55 = new Edge(5,5);
		Edge e56 = new Edge(5,6);
		Edge e57 = new Edge(5,7);
		Edge e58 = new Edge(5,8);
		Edge e59 = new Edge(5,9);
		
		Edge e60 = new Edge(6,0);
		Edge e61 = new Edge(6,1);
		Edge e62 = new Edge(6,2);
		Edge e63 = new Edge(6,3);
		Edge e64 = new Edge(6,4);
		Edge e65 = new Edge(6,5);
		Edge e66 = new Edge(6,6);
		Edge e67 = new Edge(6,7);
		Edge e68 = new Edge(6,8);
		Edge e69 = new Edge(6,9);
		
		Edge e70 = new Edge(7,0);
		Edge e71 = new Edge(7,1);
		Edge e72 = new Edge(7,2);
		Edge e73 = new Edge(7,3);
		Edge e74 = new Edge(7,4);
		Edge e75 = new Edge(7,5);
		Edge e76 = new Edge(7,6);
		Edge e77 = new Edge(7,7);
		Edge e78 = new Edge(7,8);
		Edge e79 = new Edge(7,9);
		
		Edge e80 = new Edge(8,0);
		Edge e81 = new Edge(8,1);
		Edge e82 = new Edge(8,2);
		Edge e83 = new Edge(8,3);
		Edge e84 = new Edge(8,4);
		Edge e85 = new Edge(8,5);
		Edge e86 = new Edge(8,6);
		Edge e87 = new Edge(8,7);
		Edge e88 = new Edge(8,8);
		Edge e89 = new Edge(8,9);
		
		Edge e90 = new Edge(9,0);
		Edge e91 = new Edge(9,1);
		Edge e92 = new Edge(9,2);
		Edge e93 = new Edge(9,3);
		Edge e94 = new Edge(9,4);
		Edge e95 = new Edge(9,5);
		Edge e96 = new Edge(9,6);
		Edge e97 = new Edge(9,7);
		Edge e98 = new Edge(9,8);
		Edge e99 = new Edge(9,9);
		
		
		
		
		Edge e419= new Edge(4,19);
		Edge e519= new Edge(5,19);
		Edge e619= new Edge(6,19);
		Edge e719= new Edge(7,19);
		Edge e819= new Edge(8,19);
		Edge e919= new Edge(9,19);
		Edge e1019= new Edge(10,19);
		Edge e1119= new Edge(11,19);
		Edge e1219= new Edge(12,19);
		Edge e1319= new Edge(13,19);
		Edge e1419= new Edge(14,19);
		Edge e1519= new Edge(15,19);
		Edge e1619= new Edge(16,19);
		Edge e1719= new Edge(17,19);
		Edge e1819= new Edge(18,19);
		
		Edge e1414 = new Edge(14,14);
		Edge e1515 = new Edge(15,15);
		Edge e1616 = new Edge(16,16);
		Edge e1717 = new Edge(17,17);
		Edge e1818 = new Edge(18,18);
		Edge e1919 = new Edge(19,19);
		
		Edge e910 = new Edge(9,10);
		Edge e1011 = new Edge(10,11);
		Edge e1112 = new Edge(11,12);
		Edge e1213 = new Edge(12,13);
		Edge e1314 = new Edge(13,14);
		Edge e1415 = new Edge(14,15);
		Edge e1516 = new Edge(15,16);
		Edge e1617 = new Edge(16,17);
		Edge e1718 = new Edge(17,18);
		
		Edge e1010= new Edge(10,10);
		
		Edge e1313= new Edge(13,13);
		
		Edge e1111= new Edge(11,11);
		
		Edge e1212= new Edge(12,12);
		
		Edge e118= new Edge(1,18);
		Edge e218= new Edge(2,18);
		Edge e318= new Edge(3,18);
		Edge e418= new Edge(4,18);
		Edge e518= new Edge(5,18);
		Edge e618= new Edge(6,18);
		Edge e718= new Edge(7,18);
		Edge e818= new Edge(8,18);
		Edge e918= new Edge(0,18);
		Edge e1018= new Edge(10,18);
		
		Edge e019= new Edge(0,19);
		Edge e119= new Edge(1,19);
		
		Edge e1015= new Edge(10,15);
		Edge e1215= new Edge(12,15);
		
		
		
		
		
		
		
		
		
		//e00, e11, e22, e33,e44,e55,e66,e77,e88,e99,
		//e55,e66,e77,e88,e99
		List<Edge> inter = Arrays.asList(e00,e11,e22,e33);
		
		//e45,e56,e67,e78,e89,e09,e19,e29,e39,e49,e59,e69,e79
		//e1011,e1112,e1213,e1314,e1415,e1516,e1617,e1718,e1819,e019,e119,e218,e318,e418,e1015,e1215
		//e01,e12,e23,e34,e45,e56,e67,e78,e89,e49,e59,e69,e39,e02,e24,e46,e68,e37,e04,e06,e08,e03,e13,e15,e17
		List<Edge> intra= Arrays.asList(e01,e02,e12,e13,e23);
		
		
		System.out.println("I arrived here 2");
		
		BayesNet b0 = new BayesNet(a, intra);
		b0.generateParameters();
		BayesNet bt = new BayesNet(a, intra, inter);
		
		System.out.println("I arrived here 3");
		
		
		bt.generateParameters();

		DynamicBayesNet dbn1 = new DynamicBayesNet(a, b0, Arrays.asList(bt,bt,bt,bt,bt,bt,bt,bt,bt,bt,bt,bt,bt,bt,bt));
	
		

		System.out.println(dbn1.toDot(false));
		
		
		Observations o = dbn1.generateObservations(5000);
		
		String c = new String("cDBN_1_5000");
		
		o.writeToFile(c);
		
		
		/*for(int i=0; i<5; i++) {
			System.out.println(100000+i*10000+" observations");
			
			Observations o = dbn1.generateObservations(100000+i*10000);

			Scores s = new Scores(o, 2);
			
			s.evaluate(new 	MDLScoringFunction());
			
			ScoringFunction mdl = new MDLScoringFunction();
			
			DynamicBayesNet dbn_1 = s.toDBN_Ckg(0,false,mdl,o,4);
			
			System.out.println(dbn_1.toDot(false));
			
			System.out.println("----------------------------------------------------");
			
		}*/
		
		/*Observations o = dbn1.generateObservations(1000);
		
		
		
		Scores s = new Scores(o, 2);
		
		s.evaluate(new 	MDLScoringFunction());
		
		ScoringFunction mdl = new MDLScoringFunction();
		
		DynamicBayesNet dbn_1 = s.toDBN_Ckg(0,false,mdl,o);
		DynamicBayesNet dbn_2 = s.toDBN(0,false);
		
		
		
		System.out.println(compare(dbn1,dbn_1,true));
		System.out.println("----------------------------------");
		System.out.println(compare(dbn1,dbn_2,true));*/
		
		
		
		//List<int[]> c = compare(dbn1,dbn_1);
		
		
		/*
		
		System.out.println("size"+c.size());
		
		System.out.println(Arrays.toString(c.get(0)));
		
		for(int m=0; m < c.size();m++) {
			System.out.println("m"+m);
			for(int n=0; n<c.get(m).length; n++) {
				System.out.println(c.get(m)[n]);
			}
		}*/
		
		
		/*int k=4;
		
		ArrayList<Double> ckg_mdl_per_mean = new ArrayList<Double>();
		
		ArrayList<Double> ckg_mdl_ll_per_mean = new ArrayList<Double>();
		
		ArrayList<Double> ckg_ll_per_mean = new ArrayList<Double>();
		
		ArrayList<Double> tan_ll_per_mean = new ArrayList<Double>();
		
		ArrayList<Double> tan_mdl_per_mean = new ArrayList<Double>();
		
		
		ArrayList<Double> ckg_mdl_per_sd = new ArrayList<Double>();
		
		ArrayList<Double> ckg_mdl_ll_per_sd = new ArrayList<Double>();
		
		ArrayList<Double> ckg_ll_per_sd = new ArrayList<Double>();
		
		ArrayList<Double> tan_ll_per_sd = new ArrayList<Double>();
		ArrayList<Double> tan_mdl_per_sd = new ArrayList<Double>();
		
		
		
		
		
		
		
		ArrayList<Double> ckg_mdl_rec_mean = new ArrayList<Double>();
		
		ArrayList<Double> ckg_mdl_ll_rec_mean = new ArrayList<Double>();
		
		ArrayList<Double> ckg_ll_rec_mean = new ArrayList<Double>();
		
		ArrayList<Double> tan_ll_rec_mean = new ArrayList<Double>();
		
		ArrayList<Double> tan_mdl_rec_mean = new ArrayList<Double>();
		
		
		ArrayList<Double> ckg_mdl_rec_sd = new ArrayList<Double>();
		
		ArrayList<Double> ckg_mdl_ll_rec_sd = new ArrayList<Double>();
		
		ArrayList<Double> ckg_ll_rec_sd = new ArrayList<Double>();
		
		ArrayList<Double> tan_ll_rec_sd = new ArrayList<Double>();
		ArrayList<Double> tan_mdl_rec_sd = new ArrayList<Double>();
		
		
		
		
		ArrayList<Double> ckg_mdl_f1_mean = new ArrayList<Double>();
		
		ArrayList<Double> ckg_mdl_ll_f1_mean = new ArrayList<Double>();
		
		ArrayList<Double> ckg_ll_f1_mean = new ArrayList<Double>();
		
		ArrayList<Double> tan_ll_f1_mean = new ArrayList<Double>();
		
		ArrayList<Double> tan_mdl_f1_mean = new ArrayList<Double>();
		
		
		ArrayList<Double> ckg_mdl_f1_sd = new ArrayList<Double>();
		
		ArrayList<Double> ckg_mdl_ll_f1_sd = new ArrayList<Double>();
		
		ArrayList<Double> ckg_ll_f1_sd = new ArrayList<Double>();
		
		ArrayList<Double> tan_ll_f1_sd = new ArrayList<Double>();
		ArrayList<Double> tan_mdl_f1_sd = new ArrayList<Double>();
		
		ArrayList<Long> time_ckg_ll = new ArrayList<Long>();
		ArrayList<Long> time_ckg_mdl = new ArrayList<Long>();
		ArrayList<Long> time_tan_ll = new ArrayList<Long>();
		ArrayList<Long> time_tan_mdl = new ArrayList<Long>();
		
		long start_ckg_ll=0;
		long final_ckg_ll=0;
		
		long start_ckg_mdl=0;
		long final_ckg_mdl=0;
		
		long start_tan_ll=0;
		long final_tan_ll=0;
		
		long start_tan_mdl=0;
		long final_tan_mdl=0;
		
		


		for(int i=1;i<5;i++)
		{
			System.out.println("IM IN "+i);
			
			double[] per_ckg_mdl= new double[5];
			double[] per_ckg_ll= new double[5];
			double[] per_ckg_mdl_ll= new double[5];
			
			
			double[] rec_ckg_mdl= new double[5];
			double[] rec_ckg_ll= new double[5];
			double[] rec_ckg_mdl_ll= new double[5];
			
			double[] f1_ckg_mdl= new double[5];
			double[] f1_ckg_ll= new double[5];
			double[] f1_ckg_mdl_ll= new double[5];
			
			double[] per_tan_mdl= new double[5];
			double[] per_tan_ll= new double[5];
			
			double[] rec_tan_mdl= new double[5];
			double[] rec_tan_ll= new double[5];
			
			double[] f1_tan_mdl= new double[5];
			double[] f1_tan_ll= new double[5];
			
			System.out.println("I arrived here");

			for(int j=0; j<5; j++) {
			
			
			Observations o = dbn1.generateObservations(i*250);
			
			
			
			Scores sMDL = new Scores(o, 2);
			Scores sLL = new Scores(o, 2);
			
			
			sMDL.evaluate(new 	MDLScoringFunction());
			sLL.evaluate(new 	LLScoringFunction());
			
			
			ScoringFunction ll = new LLScoringFunction();
			ScoringFunction mdl = new MDLScoringFunction();
			
			start_ckg_ll = System.currentTimeMillis();
			DynamicBayesNet dbn_1 = sLL.toDBN_Ckg(0,false,ll,o,k);
			final_ckg_ll= System.currentTimeMillis();
			per_ckg_ll[j]= compare(dbn1,dbn_1,true)[0];
			rec_ckg_ll[j]= compare(dbn1,dbn_1,true)[1];
			f1_ckg_ll[j]= compare(dbn1,dbn_1,true)[2];
			
			start_ckg_mdl = System.currentTimeMillis();
			DynamicBayesNet dbn_2 = sMDL.toDBN_Ckg(0,false,mdl,o,k);
			final_ckg_mdl= System.currentTimeMillis();
			per_ckg_mdl[j]= compare(dbn1,dbn_2,true)[0];
			rec_ckg_mdl[j]= compare(dbn1,dbn_2,true)[1];
			f1_ckg_mdl[j]= compare(dbn1,dbn_2,true)[2];
			
			//start_ckg_ll_mdl= System.currentTimeMillis();
			DynamicBayesNet dbn_3 = sMDL.toDBN_Ckg(0,false,ll,o,k);
			//final_ckg_ll_mdl= System.currentTimeMillis();
			per_ckg_mdl_ll[j]= compare(dbn1,dbn_3,true)[0];
			rec_ckg_mdl_ll[j]= compare(dbn1,dbn_3,true)[1];
			f1_ckg_mdl_ll[j]= compare(dbn1,dbn_3,true)[2];
			
			start_tan_ll= System.currentTimeMillis();
			DynamicBayesNet dbn_4 = sLL.toDBN(0,false);
			final_tan_ll= System.currentTimeMillis();
			per_tan_ll[j]= compare(dbn1,dbn_4,true)[0];
			rec_tan_ll[j]= compare(dbn1,dbn_4,true)[1];
			f1_tan_ll[j]= compare(dbn1,dbn_4,true)[2];
			
			start_tan_mdl= System.currentTimeMillis();
			DynamicBayesNet dbn_5 = sMDL.toDBN(0,false);
			final_tan_mdl= System.currentTimeMillis();
			per_tan_mdl[j]= compare(dbn1,dbn_5,true)[0];
			rec_tan_mdl[j]= compare(dbn1,dbn_5,true)[1];
			f1_tan_mdl[j]= compare(dbn1,dbn_5,true)[2];
			
			
			System.out.println("time ckg+ll"+(final_ckg_ll-start_ckg_ll));
			System.out.println("time ckg+mdl"+(final_ckg_mdl-start_ckg_mdl));
			//System.out.println("time ckg+ll+mdl"+(final_ckg_ll_mdl-start_ckg_ll_mdl));
			System.out.println("time tan+ll"+(final_tan_ll-start_tan_ll));
			System.out.println("time tan+mdl"+(final_tan_mdl-start_tan_mdl));
			

			
		}
			
			time_ckg_ll.add((final_ckg_ll-start_ckg_ll));
			time_ckg_mdl.add((final_ckg_mdl-start_ckg_mdl));
			time_tan_ll.add((final_tan_ll-start_tan_ll));
			time_tan_mdl.add((final_tan_mdl-start_tan_mdl));
			
			
			
			double mean_per_ckg_ll = Mean(per_ckg_ll);
			double mean_rec_ckg_ll = Mean(rec_ckg_ll);
			double mean_f1_ckg_ll = Mean(f1_ckg_ll);
			
			
			
			double sd_per_ckg_ll = StandDes(per_ckg_ll,mean_per_ckg_ll);
			double sd_rec_ckg_ll = StandDes(rec_ckg_ll,mean_rec_ckg_ll);
			double sd_f1_ckg_ll = StandDes(f1_ckg_ll,mean_f1_ckg_ll);
			
			
			double mean_per_ckg_mdl = Mean(per_ckg_mdl);
			double mean_rec_ckg_mdl = Mean(rec_ckg_mdl);
			double mean_f1_ckg_mdl = Mean(f1_ckg_mdl);
			
			double sd_per_ckg_mdl = StandDes(per_ckg_mdl,mean_per_ckg_mdl);
			double sd_rec_ckg_mdl = StandDes(rec_ckg_mdl,mean_rec_ckg_mdl);
			double sd_f1_ckg_mdl = StandDes(f1_ckg_mdl,mean_f1_ckg_mdl);
			
			
			double mean_per_ckg_mdl_ll = Mean(per_ckg_mdl_ll);
			double mean_rec_ckg_mdl_ll = Mean(rec_ckg_mdl_ll);
			double mean_f1_ckg_mdl_ll = Mean(f1_ckg_mdl_ll);
			
			double sd_per_ckg_mdl_ll = StandDes(per_ckg_mdl_ll,mean_per_ckg_mdl_ll);
			double sd_rec_ckg_mdl_ll = StandDes(rec_ckg_mdl_ll,mean_rec_ckg_mdl_ll);
			double sd_f1_ckg_mdl_ll = StandDes(f1_ckg_mdl_ll,mean_f1_ckg_mdl_ll);
			
			
			double mean_per_tan_ll = Mean(per_tan_ll);
			double mean_rec_tan_ll = Mean(rec_tan_ll);
			double mean_f1_tan_ll = Mean(f1_tan_ll);
			
			double sd_per_tan_ll = StandDes(per_tan_ll,mean_per_tan_ll);
			double sd_rec_tan_ll = StandDes(rec_tan_ll,mean_rec_tan_ll);
			double sd_f1_tan_ll = StandDes(f1_tan_ll,mean_f1_tan_ll);
			
			double mean_per_tan_mdl = Mean(per_tan_mdl);
			double mean_rec_tan_mdl = Mean(rec_tan_mdl);
			double mean_f1_tan_mdl = Mean(f1_tan_mdl);
			
			double sd_per_tan_mdl = StandDes(per_tan_mdl,mean_per_tan_mdl);
			double sd_rec_tan_mdl = StandDes(rec_tan_mdl,mean_rec_tan_mdl);
			double sd_f1_tan_mdl = StandDes(f1_tan_mdl,mean_f1_tan_mdl);
			
			
			
			
			
			 ckg_mdl_per_mean.add(mean_per_ckg_mdl);
			
			 ckg_mdl_ll_per_mean.add(mean_per_ckg_mdl_ll);
			
			ckg_ll_per_mean.add(mean_per_ckg_ll);
			
			 tan_ll_per_mean.add(mean_per_tan_ll);
			 
			tan_mdl_per_mean.add(mean_per_tan_mdl);
			
			
			ckg_mdl_per_sd.add(sd_per_ckg_mdl);
			
			ckg_mdl_ll_per_sd.add(sd_per_ckg_mdl_ll);
			
			ckg_ll_per_sd.add(sd_per_ckg_ll);
			
			tan_ll_per_sd.add(sd_per_tan_ll);
			tan_mdl_per_sd.add(sd_per_tan_mdl);
			
			
			
			ckg_mdl_rec_mean.add(mean_rec_ckg_mdl);
			
			 ckg_mdl_ll_rec_mean.add(mean_rec_ckg_mdl_ll);
			
			ckg_ll_rec_mean.add(mean_rec_ckg_ll);
			
			 tan_ll_rec_mean.add(mean_rec_tan_ll);
			 
			tan_mdl_rec_mean.add(mean_rec_tan_mdl);
			
			
			ckg_mdl_rec_sd.add(sd_rec_ckg_mdl);
			
			ckg_mdl_ll_rec_sd.add(sd_rec_ckg_mdl_ll);
			
			ckg_ll_rec_sd.add(sd_rec_ckg_ll);
			
			tan_ll_rec_sd.add(sd_rec_tan_ll);
			tan_mdl_rec_sd.add(sd_rec_tan_mdl);
			
			
			ckg_mdl_f1_mean.add(mean_f1_ckg_mdl);
			
			 ckg_mdl_ll_f1_mean.add(mean_f1_ckg_mdl_ll);
			
			ckg_ll_f1_mean.add(mean_f1_ckg_ll);
			
			 tan_ll_f1_mean.add(mean_f1_tan_ll);
			 
			tan_mdl_f1_mean.add(mean_f1_tan_mdl);
			
			
			ckg_mdl_f1_sd.add(sd_f1_ckg_mdl);
			
			ckg_mdl_ll_f1_sd.add(sd_f1_ckg_mdl_ll);
			
			ckg_ll_f1_sd.add(sd_f1_ckg_ll);
			
			tan_ll_f1_sd.add(sd_f1_tan_ll);
			tan_mdl_f1_sd.add(sd_f1_tan_mdl);
				
				
		}
		
		
		
		
		
		
		
		
		
		System.out.println("Precision");
		
		System.out.println("CkG+LL");
		
		System.out.println(ckg_ll_per_mean);
		System.out.println(ckg_ll_per_sd);

		
		System.out.println("CkG+MDL");
		
		System.out.println(ckg_mdl_per_mean);
		System.out.println(ckg_mdl_per_sd);
		
		
		System.out.println("CkG+MDL+LL");
		
		System.out.println(ckg_mdl_ll_per_mean);
		System.out.println(ckg_mdl_ll_per_sd);
		
		
		System.out.println("TAN+LL");
		
		System.out.println(tan_ll_per_mean);
		System.out.println(tan_ll_per_sd);
		
		System.out.println("TAN+MDL");
		
		System.out.println(tan_mdl_per_mean);
		System.out.println(tan_mdl_per_sd);
		
		
		
		
		System.out.println("Recall");
		
		System.out.println("CkG+LL");
		
		System.out.println(ckg_ll_rec_mean);
		System.out.println(ckg_ll_rec_sd);

		
		System.out.println("CkG+MDL");
		
		System.out.println(ckg_mdl_rec_mean);
		System.out.println(ckg_mdl_rec_sd);
		
		
		System.out.println("CkG+MDL+LL");
		
		System.out.println(ckg_mdl_ll_rec_mean);
		System.out.println(ckg_mdl_ll_rec_sd);
		
		
		System.out.println("TAN+LL");
		
		System.out.println(tan_ll_rec_mean);
		System.out.println(tan_ll_rec_sd);
		
		System.out.println("TAN+MDL");
		
		System.out.println(tan_mdl_rec_mean);
		System.out.println(tan_mdl_rec_sd);
		
		
		
		System.out.println("F1");
		
		System.out.println("CkG+LL");
		
		System.out.println(ckg_ll_f1_mean);
		System.out.println(ckg_ll_f1_sd);

		
		System.out.println("CkG+MDL");
		
		System.out.println(ckg_mdl_f1_mean);
		System.out.println(ckg_mdl_f1_sd);
		
		
		System.out.println("CkG+MDL");
		
		System.out.println(ckg_mdl_ll_f1_mean);
		System.out.println(ckg_mdl_ll_f1_sd);
		
		
		System.out.println("TAN+LL");
		
		System.out.println(tan_ll_f1_mean);
		System.out.println(tan_ll_f1_sd);
		
		System.out.println("TAN+MDL");
		
		System.out.println(tan_mdl_f1_mean);
		System.out.println(tan_mdl_f1_sd);
		
		
		System.out.println("Time");
		
		System.out.println(time_ckg_ll);
		
		System.out.println(time_ckg_mdl);
		
		System.out.println(time_tan_ll);
		
		System.out.println(time_tan_mdl);*/
			
			
			
			
			
		

		/*Observations o = dbn1.generateObservations(500);
		

		Scores s = new Scores(o, 2);
		
		s.evaluate(new LLScoringFunction());
		
		ScoringFunction mdl = new MDLScoringFunction();
		
		DynamicBayesNet dbn = s.toDBN(0,false);
		
		System.out.println(dbn.toDot(false));
		
		
		DynamicBayesNet dbn_1 = s.toDBN_Ckg(0,false,mdl,o);
		
		System.out.println(dbn_1.toDot(false));*/
		
		
		
		
		
		
		
		
		
		
		
		
		// a really simple network

		/*Attribute a1 = new NominalAttribute();
		a1.setName("me");
		a1.add("yes");
		a1.add("no");

		Attribute a2 = new NumericAttribute();
		a2.add("10");
		a2.add("20");

		Attribute a3 = new NumericAttribute();
		a3.add("0");
		a3.add("1");

		Attribute a4 = new NumericAttribute();
		a4.add("0");
		a4.add("1");

		Attribute a5 = new NumericAttribute();
		a5.add("0");
		a5.add("1");

		Attribute a6 = new NumericAttribute();
		a6.add("0");
		a6.add("1");

		List<Attribute> a = Arrays.asList(a1, a2, a3, a4, a5, a6);

		Edge e1 = new Edge(0, 0);
		Edge e2 = new Edge(0, 1);
		Edge e3 = new Edge(0, 2);
		Edge e4 = new Edge(0, 3);
		Edge e5 = new Edge(0, 4);
		Edge e6 = new Edge(0, 5);
		Edge e7 = new Edge(1, 0);
		Edge e8 = new Edge(1, 1);
		Edge e9 = new Edge(1, 2);
		Edge e10 = new Edge(1, 3);
		Edge e11 = new Edge(1, 4);
		Edge e12 = new Edge(1, 5);
		Edge e13 = new Edge(2, 0);
		Edge e14 = new Edge(2, 1);
		Edge e15 = new Edge(2, 2);
		Edge e16 = new Edge(2, 3);
		Edge e17 = new Edge(2, 4);
		Edge e18 = new Edge(2, 5);
		Edge e19 = new Edge(3, 0);
		Edge e20 = new Edge(3, 1);
		Edge e21 = new Edge(3, 2);
		Edge e22 = new Edge(3, 3);
		Edge e23 = new Edge(3, 4);
		Edge e24 = new Edge(3, 5);
		Edge e25 = new Edge(4, 0);
		Edge e26 = new Edge(4, 1);
		Edge e27 = new Edge(4, 2);
		Edge e28 = new Edge(4, 3);
		Edge e29 = new Edge(4, 4);
		Edge e30 = new Edge(4, 5);
		Edge e31 = new Edge(5, 0);
		Edge e32 = new Edge(5, 1);
		Edge e33 = new Edge(5, 2);
		Edge e34 = new Edge(5, 3);
		Edge e35 = new Edge(5, 4);
		Edge e36 = new Edge(5, 5);
		
		Edge e37 = new Edge(2,4);
		Edge e38 = new Edge(3,2);

		// 0 -> 1 -> 2 -> 3 -> 4 -> 5
		List<Edge> intra = Arrays.asList(e2, e9, e16, e23, e30,e37);
		
		//List<Edge> intra = Arrays.asList(e37,e38);
		
		

		//
		List<Edge> inter = Arrays.asList(e1, e4, e8, e15, e16, e20, e22, e26, e28, e31, e32, e34, e35);

		BayesNet b0 = new BayesNet(a, intra);
		b0.generateParameters();
		BayesNet bt = new BayesNet(a, intra, inter);
		
		
		bt.generateParameters();

		DynamicBayesNet dbn1 = new DynamicBayesNet(a, b0, Arrays.asList(bt));*/
		

		/*Observations o = dbn1.generateObservations(500);
		

		Scores s = new Scores(o, 2);
		
		s.evaluate(new LLScoringFunction());
		
		ScoringFunction mdl = new MDLScoringFunction();
		
		DynamicBayesNet dbn = s.toDBN(0,false);
		
		System.out.println(dbn.toDot(false));
		
		
		DynamicBayesNet dbn_1 = s.toDBN_Ckg(0,false,mdl,o);
		
		System.out.println(dbn_1.toDot(false));*/
		
		
		
		
		
		
/*
		Observations o1 = dbn1.generateObservations(100);
		
		Observations o2 = dbn1.generateObservations(200);
		
		Observations o3 = dbn1.generateObservations(300);
		
		Observations o4 = dbn1.generateObservations(400);
		
		Observations o5 = dbn1.generateObservations(500);
		
		Observations o6 = dbn1.generateObservations(600);
		
		Observations o7 = dbn1.generateObservations(700);
		
		Observations o8 = dbn1.generateObservations(700);
		
		ScoringFunction mdl = new MDLScoringFunction();
		
		System.out.println(dbn1.toDot(false));
		

		System.out.println("------------------------------------------");
		Scores s1 = new Scores(o1, 2);
		
		s1.evaluate(new LLScoringFunction());
		
		
		DynamicBayesNet dbn_1 = s1.toDBN_Ckg(0,false,mdl,o1);
		
		System.out.println(dbn_1.toDot(false));
		
		System.out.println("-------------------------------------------");
		

		Scores s2 = new Scores(o2, 2);
		
		s2.evaluate(new LLScoringFunction());
		
		DynamicBayesNet dbn_2 = s2.toDBN_Ckg(0,false,mdl,o2);
		
		System.out.println(dbn_2.toDot(false));
		
		System.out.println("-------------------------------------------");
		

		Scores s3 = new Scores(o3, 2);
		
		s3.evaluate(new LLScoringFunction());
		
		ScoringFunction mdl3 = new LLScoringFunction();
		
		DynamicBayesNet dbn_3 = s2.toDBN_Ckg(0,false,mdl,o3);
		
		System.out.println(dbn_3.toDot(false));
		
		System.out.println("-------------------------------------------");
		

		Scores s4 = new Scores(o4, 2);
		
		s4.evaluate(new LLScoringFunction());
		
		DynamicBayesNet dbn_4 = s2.toDBN_Ckg(0,false,mdl,o4);
		
		System.out.println(dbn_4.toDot(false));
		
	System.out.println("-------------------------------------------");
		

		Scores s5 = new Scores(o5, 2);
		
		s5.evaluate(new LLScoringFunction());
		
		
		DynamicBayesNet dbn_5 = s2.toDBN_Ckg(0,false,mdl,o5);
		
		System.out.println(dbn_5.toDot(false));
		
		
	System.out.println("-------------------------------------------");
		

		Scores s6 = new Scores(o6, 2);
		
		s5.evaluate(new LLScoringFunction());
		
		
		DynamicBayesNet dbn_6 = s2.toDBN_Ckg(0,false,mdl,o6);
		
		System.out.println(dbn_6.toDot(false));
		
		
		
		
		System.out.println("-------------------------------------------");
			

			Scores s7 = new Scores(o7, 2);
			
			s5.evaluate(new LLScoringFunction());
			
			
			DynamicBayesNet dbn_7 = s2.toDBN_Ckg(0,false,mdl,o6);
			
			System.out.println(dbn_7.toDot(false));
		
			
System.out.println("-------------------------------------------");
			

			Scores s8 = new Scores(o8, 2);
			
			s5.evaluate(new LLScoringFunction());
			
			
			DynamicBayesNet dbn_8 = s2.toDBN_Ckg(0,false,mdl,o6);
			
			System.out.println(dbn_8.toDot(false));


		//System.out.println(s.toString());

		//System.out.println(OptimumBranching.evaluate(s.getScoresMatrix()));

		//DynamicBayesNet dbn2 = s.toDBN(0,false);
		

		
		//DynamicBayesNet dbn3 = s.toDBN_Ckg(-1,false,mdl,o);
		
	
		
		/*System.out.println("True:");
		System.out.println(dbn1.toDot(false));
		
		
		System.out.println("Experience 1:");
		System.out.println(dbn2.toDot(false));
		
		System.out.println("Experience 2:");
		System.out.println(dbn3.toDot(false));*/
		
		
	}

}
